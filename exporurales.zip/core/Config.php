<?php

//aqui va la configuracion general del mvc

define('BASE_URL', 'http://localhost/exporurales/');
define('DEFAULT_CONTROLLER', 'inicio');
define('DEFAULT_LAYOUT', 'default');

define('APP_NAME', "<label style='color:red'>Expo</label>rurales");
define('APP_COMPANY', ' - SENA Equipo ADSI 597864 - Exporurales');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'admin');
define('DB_NAME', 'exporurales');
define('DB_CHAR', 'utf8');

