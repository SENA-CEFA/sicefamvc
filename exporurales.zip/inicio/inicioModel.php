<?php

class inicioModel extends Model
{
    public function __construct() {
        parent::__construct();
    }

    function delete($arg = false) {
        
    }

    function edit($arg = false) {
        
    }

    function get($arg = false) {
    
    }

    function set($arg = false) {
        
    }
    function consolidar(){
        $data = $this->_db->query("SELECT Nombre FROM categorias");
        return $data->fetchall();
    }

}


?>
