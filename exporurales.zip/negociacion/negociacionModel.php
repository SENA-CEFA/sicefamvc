<?php

class parametrosModel extends Model
{
    public function __construct() {
        parent::__construct();
    }

    function delete() {
        
    }

    function edit() {
        
    }

    function get() {
    
    }

    function set() {
        
    }

}


?>
